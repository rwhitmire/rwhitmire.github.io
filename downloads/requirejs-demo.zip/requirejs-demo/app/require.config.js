var require = {
    baseUrl: ".",
    paths: {
        "jquery": "bower_components/jquery/dist/jquery",
        "bootstrap": "bower_components/bootstrap/dist/js/bootstrap",
        "knockout": "bower_components/knockout/dist/knockout"
    },
    shim: {
        "bootstrap": { deps: ["jquery"] }
    }
};
