define(['knockout', 'app/viewmodels/home', 'bootstrap'], function(ko, viewModel) {

    ko.applyBindings(viewModel);

});
