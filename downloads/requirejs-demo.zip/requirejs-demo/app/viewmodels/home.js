define(['knockout'], function(ko){

	function HomeViewModel(){
		this.message = "hello world!";
	}

	return HomeViewModel;

});